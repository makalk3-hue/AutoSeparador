# Auto Separador — projeto Android inicial

Projeto inicial para Motorola Moto G22 / Android 12. O app tem uma chave liga/desliga e um serviço de Acessibilidade que, quando ativado, procura **somente** o texto exato `Iniciar Separação` na árvore de acessibilidade do Google Chrome e tenta clicar no elemento ou em seu contêiner clicável.

## Limitações importantes

- Este é um protótipo de código-fonte, não um APK já compilado ou testado no Moto G22.
- A automação depende de o site expor o botão como texto acessível no Chrome. Se o botão não aparecer na árvore de acessibilidade, será necessário ajustar a estratégia após um teste real.
- O clique só é tentado quando o botão está visível e o serviço está ligado. O app não procura nem clica em “Continuar Separação”.
- A velocidade depende do carregamento do site e dos eventos de acessibilidade; não é possível garantir tempo exato.
- O serviço é limitado ao pacote do Google Chrome. Use a automação apenas quando estiver na página correta e conforme as regras do serviço/plataforma.

## Como gerar o APK

1. Abra o projeto `AutoSeparador` no Android Studio atualizado.
2. Aguarde a sincronização do Gradle e instale o Android SDK Platform 35 se solicitado.
3. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfira o APK para o Moto G22 e instale. Talvez seja necessário permitir a instalação pelo aplicativo usado para abrir o arquivo.
6. Abra **Auto Separador**, toque em **Configurar acessibilidade** e habilite o serviço **Auto Separador**.
7. Volte ao app e ligue a chave. Teste primeiro com cuidado, observando se o botão correto é acionado.

## Estrutura

- `MainActivity.kt`: tela e chave liga/desliga.
- `AutoClickAccessibilityService.kt`: reconhecimento do botão e clique.
- `accessibility_service_config.xml`: configura o serviço para observar o Chrome.
