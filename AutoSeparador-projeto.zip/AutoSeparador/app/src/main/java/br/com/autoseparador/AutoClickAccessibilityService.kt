package br.com.autoseparador

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock
import java.text.Normalizer
import java.util.Locale

class AutoClickAccessibilityService : AccessibilityService() {
    private var clickedOnCurrentScreen = false
    private var lastClickAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName?.toString() != CHROME_PACKAGE) return
        if (!getSharedPreferences("auto_separador", MODE_PRIVATE)
                .getBoolean(MainActivity.KEY_ENABLED, false)) return

        val root = rootInActiveWindow ?: return
        val target = findStartButton(root)
        if (target == null) {
            clickedOnCurrentScreen = false
            return
        }
        if (clickedOnCurrentScreen) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastClickAt < CLICK_GUARD_MS) return

        val clickable = findClickableAncestor(target) ?: target
        val success = clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (success) {
            clickedOnCurrentScreen = true
            lastClickAt = now
        }
    }

    private fun findStartButton(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            val node = stack.removeLast()
            if (node.isVisibleToUser && (matches(node.text) || matches(node.contentDescription))) {
                return node
            }
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { stack.add(it) }
            }
        }
        return null
    }

    private fun matches(value: CharSequence?): Boolean {
        if (value == null) return false
        val normalized = Normalizer.normalize(value.toString(), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .trim().lowercase(Locale.ROOT)
        return normalized == "iniciar separacao"
    }

    private fun findClickableAncestor(start: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var node: AccessibilityNodeInfo? = start
        repeat(6) {
            if (node == null) return null
            if (node!!.isClickable) return node
            node = node!!.parent
        }
        return null
    }

    override fun onInterrupt() = Unit

    companion object {
        private const val CHROME_PACKAGE = "com.android.chrome"
        private const val CLICK_GUARD_MS = 1800L
    }
}
