package br.com.autoseparador

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Switch
import android.widget.Button

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("auto_separador", MODE_PRIVATE) }
    private lateinit var state: TextView
    private lateinit var toggle: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (22 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFFF7F7F8.toInt())
        }
        val title = TextView(this).apply {
            text = "Auto Separador"
            textSize = 27f
            setTextColor(0xFF171717.toInt())
        }
        val intro = TextView(this).apply {
            text = "Automatiza somente o botão “Iniciar Separação” no Separador iFood aberto pelo Google Chrome."
            textSize = 16f
            setTextColor(0xFF444444.toInt())
            setPadding(0, pad / 2, 0, pad)
        }
        toggle = Switch(this).apply {
            text = "Automação ativada"
            textSize = 18f
            isChecked = prefs.getBoolean(KEY_ENABLED, false)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(KEY_ENABLED, checked).apply()
                text = if (checked) "Automação ativada" else "Automação desativada"
                updateState()
            }
        }
        state = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF555555.toInt())
            setPadding(0, pad / 2, 0, pad)
        }
        val settingsButton = Button(this).apply {
            text = "Configurar acessibilidade"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val note = TextView(this).apply {
            text = "Importante: ative o serviço “Auto Separador” nas configurações de Acessibilidade do Android. O Android exibirá um aviso porque esse recurso pode interagir com a tela. Use somente enquanto estiver trabalhando no Separador iFood."
            textSize = 13f
            setTextColor(0xFF666666.toInt())
            setPadding(0, pad, 0, 0)
        }
        root.addView(title)
        root.addView(intro)
        root.addView(toggle)
        root.addView(state, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(settingsButton)
        root.addView(note)
        setContentView(root)
        updateState()
    }

    override fun onResume() {
        super.onResume()
        updateState()
    }

    private fun updateState() {
        if (!::state.isInitialized) return
        val enabled = prefs.getBoolean(KEY_ENABLED, false)
        state.text = if (enabled) {
            "Pronto: ao abrir um pedido no Chrome, o app procurará o botão exato."
        } else {
            "Desligado: o Chrome continuará funcionando normalmente, sem cliques automáticos."
        }
    }

    companion object { const val KEY_ENABLED = "automation_enabled" }
}
